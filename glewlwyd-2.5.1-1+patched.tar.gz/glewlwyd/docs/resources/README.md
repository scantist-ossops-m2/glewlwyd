# Token validation for resource services

This folder contains example of token validation for a resource service. A token is provided in the HTTP request as described in the [RFC 6750](https://tools.ietf.org/html/rfc6750) concerning the Bearer token.

If you want to add other examples in different languages or different contexts for a Glewlwyd token, feel free to post a pull request or contact me.
